using System.CommandLine;
using System.Text.Json;

namespace ForceCalculator.Cli.Commands;
public class ExperimentCommand
{
    private readonly Option<PlatformType> _platformTypeOption =
        new("--platform-type", "Specifies the platform generation pattern.");

    private readonly Option<int> _supportsNumberOption =
        new("--supports-number", () => 6, "Specifies the number of the supports.");

    private readonly Option<RobotsType> _robotsTypeOption =
        new("--robots-type", "Specifies the robots placing pattern.");

    private readonly Option<int> _robotsNumberOption =
        new("--robots-number", () => 6, "Specifies the number of the supports.");

    private readonly Option<int> _countOption =
        new("--count", () => 1, "Number of generated cases.");

    private readonly Option<FileInfo?> _saveToOption =
        new("--save-to", () => null, "The path to save the results to.");

    public Command Command { get; }

    public ExperimentCommand()
    {
        Command = new Command("experiment", "Generate the results for the specified cases.")
        {
            _platformTypeOption,
            _supportsNumberOption,
            _robotsTypeOption,
            _robotsNumberOption,
            _countOption,
            _saveToOption
        };

        Command.SetHandler((platform, supportsNumber, robots, robotsNumber, count, saveTo) =>
            {
                if(saveTo != null && saveTo.Exists)
                {
                    Console.WriteLine($"File {saveTo.FullName} already exists.");
                    return;
                }

                CaseGenerator generator = new(-100, platform, supportsNumber, robots, robotsNumber);

                List<CaseData> cases = new List<CaseData>(count);
                for(int i = 0; i < count; i++)
                {
                    CaseData caseData = generator.Next();
                    cases.Add(caseData);
                    Program.WriteProgressBar(i + 1, count);
                }

                if(saveTo != null)
                {
                    ExperimentData data = new()
                    {
                        SupportsGenerationType = platform,
                        SupportsGenerationTypeDescription = platform.ToString(),
                        SupportsNumber = supportsNumber,
                        RobotsGenerationType = robots,
                        RobotsGenerationTypeDescription = robots.ToString(),
                        RobotsNumber = robotsNumber,
                        CaseNumber = count,
                        Cases = cases,
                    };

                    using var stream = new FileStream(saveTo.FullName, FileMode.Create);
                    JsonSerializer.Serialize(stream, data, new JsonSerializerOptions { WriteIndented = true });

                    Console.WriteLine($"\nExperiment data saved to {saveTo.FullName}.");
                }
            },
            _platformTypeOption, _supportsNumberOption, _robotsTypeOption,
            _robotsNumberOption, _countOption, _saveToOption);
    }
}