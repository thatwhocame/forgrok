﻿using GeometryLib;

namespace ForceCalculationLib
{
    public class Platform
    {
        public readonly float GravityForce;
        public readonly Supports Supports;
        public readonly Robot[] Robots;



        public Platform(Vector2F[] supportPositions, Vector2F[] robotPositions) : this(supportPositions, robotPositions, 0) { }

        public Platform(Vector2F[] supportPositions, Vector2F[] robotPositions, float gravityForce)
        {
            if(gravityForce > 0)
                throw new ArgumentException("Сила тяжести должна быть < 0");

            Supports = Supports.FromPositions(supportPositions);

            Robots = new Robot[robotPositions.Length];
            for(int i = 0; i < robotPositions.Length; i++)
                Robots[i] = new Robot(robotPositions[i]);

            GravityForce = gravityForce;
        }

        public Platform(Supports supports, Robot[] robots, float gravity)
		{
			if(gravity > 0)
				throw new ArgumentException("Сила тяжести должна быть < 0");

			Supports = supports;
            Robots = robots;

            GravityForce = gravity;
        }
    }
}
