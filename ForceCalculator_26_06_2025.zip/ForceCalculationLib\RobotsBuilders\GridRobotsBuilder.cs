﻿namespace ForceCalculationLib.RobotsBuilders
{
    public class GridRobotsBuilder : IRobotsBuilder
    {
        public Robot[] Build(Supports supports, int count, int seed)
        {
            throw new NotImplementedException();
        }
    }
}
