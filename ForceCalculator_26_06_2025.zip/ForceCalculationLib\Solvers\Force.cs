﻿namespace ForceCalculationLib.Solvers;
public struct Force(float position, float value)
{
	public float Position = position;
	public float Value = value;
}
