using System.CommandLine;
using System.Text.Json;

namespace ForceCalculator.Cli.Commands;
public class AnalyzeCommand
{
    private readonly Option<FileInfo> _fromFileOption =
        new("--from-file", "The path to experiment file.");

    public Command Command { get; }

    public AnalyzeCommand()
    {
        Command = new Command("analyze", "Analyzes the results of the experiment.")
        {
            _fromFileOption
        };
        
        Command.SetHandler(file =>
        {
            if(!file.Exists)
            {
                Console.WriteLine($"File {file.FullName} does not exist.");
                return;
            }
            
            using var stream = new FileStream(file.FullName, FileMode.Open);
            ExperimentData? data = JsonSerializer.Deserialize<ExperimentData>(stream);

            if(data == null)
            {
                Console.WriteLine($"File {file.FullName} could not be deserialized.");
                return;
            }
            
            Console.WriteLine($"File {file.FullName} deserialized successfully.");
            
            int total = data.Cases.Count();
            Console.WriteLine();
            Console.WriteLine($"Total cases: {total}");
            Console.WriteLine($"Supports generation pattern: {data.SupportsGenerationType}");
            Console.WriteLine($"Robots generation pattern: {data.RobotsGenerationType}");

            int validEqual = 0;
            int validIndividual = 0;
            
            List<float> equalValidForces = [];
            List<float> individualOnEqualValidForces = [];
            List<float> individualValidForces = [];

            List<float> improvementInPercent = [];

            foreach(CaseData dataCase in data.Cases)
            {
                if(dataCase.IsEqualSolvedValid)
                {
                    validEqual++;
                    equalValidForces.Add(dataCase.EqualRobotForceSum);
                }

                if(dataCase.IsIndividualSolvedValid)
                {
                    validIndividual++;
                    individualValidForces.Add(dataCase.IndividualRobotForceSum);

                    if(dataCase.IsEqualSolvedValid)
                    {
                        individualOnEqualValidForces.Add(dataCase.IndividualRobotForceSum);
                        improvementInPercent.Add((dataCase.IndividualRobotForceSum - dataCase.EqualRobotForceSum) / dataCase.EqualRobotForceSum);
                    }
                }
            }
            
            if(equalValidForces.Count == 0)
                equalValidForces.Add(0);
            if(individualValidForces.Count == 0)
                individualValidForces.Add(0);
            if(individualOnEqualValidForces.Count == 0)
                individualOnEqualValidForces.Add(0);

            float averageEqualForce = equalValidForces.Average();
            float averageIndividual = individualValidForces.Average();
            float averageIndividualOnEqualForce = individualOnEqualValidForces.Average();
            
            Console.WriteLine("------------------");
            Console.WriteLine($"Valid equal solver cases: {validEqual} ({validEqual / (float)total * 100:F2}%)");
            Console.WriteLine($"Average equal solver force: {averageEqualForce:F2}");        
            Console.WriteLine("------------------");
            Console.WriteLine($"Valid individual solver cases: {validIndividual} ({validIndividual / (float)total * 100:F2}%)");
            Console.WriteLine($"Average individual solver force: {averageIndividual:F2}");
            Console.WriteLine("------------------");
            Console.WriteLine($"Average individual solver force (on equal also valid): {averageIndividualOnEqualForce:F2}");
            Console.WriteLine($"Individual valid when equal not valid: {(validIndividual - validEqual) / (float)(total - validEqual) * 100:F2}%");
            Console.WriteLine($"Individual force gain: {(averageIndividual - averageEqualForce) / averageIndividual * 100:F2}%");
            Console.WriteLine("------------------");
            
            WriteSplitInfo(2f, 0.1f, improvementInPercent.ToArray());
            Console.WriteLine("Data analyze finished.");

        }, _fromFileOption);
    }
    
    private static void WriteSplitInfo(float to, float step, float[] data)
    {
        float divider = data.Length / 100f;
        float min = float.MinValue;
        for(float max = step; Math.Abs(max - to) < 0.01f || max < to; max += step)
        {
            float casePercentage = data.Count(f => f > min && f <= max) / divider;
            Console.WriteLine($"Improve {max * 100:F0}%: \t{casePercentage:F2}\t%");
            min = max;
        }
        
        float t = data.Count(f => f > min) / divider;
        Console.WriteLine($"Improve >{min * 100:F0}%: \t{t:F2}\t%");
    }
}