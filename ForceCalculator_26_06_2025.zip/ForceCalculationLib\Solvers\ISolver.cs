﻿namespace ForceCalculationLib.Solvers
{
    public interface ISolver
    {
        public float Solve(Platform platform);
    }
}
