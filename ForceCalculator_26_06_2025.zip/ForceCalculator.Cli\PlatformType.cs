namespace ForceCalculator.Cli;
public enum PlatformType
{
    AllRandom,
    Circle,
    TwoLine
}