﻿using System.CommandLine;
using System.Text;
using ForceCalculator.Cli.Commands;

namespace ForceCalculator.Cli;
class Program
{
    private static async Task Main(string[] args)
    {
        var rootCommand = new RootCommand("Force Calculator CLI");

        var experiment = new ExperimentCommand();
        rootCommand.AddCommand(experiment.Command);
        
        var analyze = new AnalyzeCommand();
        rootCommand.AddCommand(analyze.Command);
        
        await rootCommand.InvokeAsync(args);
    }

    public static void WriteProgressBar(int now, int total)
    {
        int length = 50;
        int filled = (int)(length * ((now + 1) / (float)total));
        int empty = length - filled;

        StringBuilder sb = new();
        sb.Append('\r');
        sb.Append("Progress: ");
        sb.Append('\u2593', filled);
        sb.Append('\u2591', empty);
        sb.Append('\t');
        sb.Append(now);
        sb.Append('/');
        sb.Append(total);
        Console.Write(sb.ToString());
    }
}