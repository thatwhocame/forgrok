﻿namespace ForceCalculationLib.SupportsBuilders
{
    public interface ISupportsBuilder
    {
        public Supports Build(int count, int seed);
    }
}
