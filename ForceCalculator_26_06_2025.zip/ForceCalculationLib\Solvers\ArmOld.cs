﻿namespace ForceCalculationLib.Solvers
{
    public class ArmOld
    {
        public float Position;



        public ArmOld()
        {
            Position = 0;
        }

        public ArmOld(float position)
        {
            Position = position;
        }
    }
}
