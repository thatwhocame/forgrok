﻿namespace ForceCalculationLib.Solvers
{
	public class EqualMaxSolver : ISolver
	{
		public float Solve(Platform platform)
		{
			var cases = SolverHelper.CreateSolvingCases(platform.Supports);

			float minForce = float.MaxValue;
			foreach(var supportPair in cases)
			{
				float force = SolveCase(platform, supportPair.First, supportPair.Second);
				if(force < minForce)
					minForce = force;
			}

			foreach(var robot in platform.Robots)
				robot.PushingForce = minForce;

			return minForce;
		}


		private float SolveCase(Platform platform, Support firstSupport, Support secondSupport)
		{
			Diagram diagram = Diagram.FromPlatform(platform, firstSupport, secondSupport);

			Arm[] robotArms = [.. diagram.RobotForces.Select(f => new Arm(f.Position))];

			float maxRobotForce1 = CalculateMaxRobotForce(diagram.Supports[0], diagram.GravityForce, robotArms);
			float maxRobotForce2 = CalculateMaxRobotForce(diagram.Supports[1], diagram.GravityForce, robotArms);

			return Math.Min(maxRobotForce1, maxRobotForce2);
		}

		/// <summary>
		/// Рассчитывает силу роботов с помощью приравнивания суммы моментов к нулю.
		/// Уравнение строится вокруг одной опоры, а сила реакции другой приравнивается к 0.
		/// </summary>
		/// <param name="support">Опора, относительно которой строится уравнение.</param>
		/// <param name="gravity">Сила тяжести.</param>
		/// <param name="robots">Плечи роботов.</param>
		private float CalculateMaxRobotForce(Arm support, Force gravity, Arm[] robots)
		{
			float shift = -support.Position;

			gravity.Position += shift;

			float cumulateRobotArm = 0;
			foreach(Arm robot in robots)
			{
				float unbiasedRobotPosition = robot.Position + shift;
				cumulateRobotArm += unbiasedRobotPosition;
			}

			return -(gravity.Value * gravity.Position) / cumulateRobotArm;
		}

		public float CalculateMaxRobotForce(ArmOld baseSupport, ArmOld targetSupport, ForceOld gravity, ArmOld[] robots, float minN)
		{
			float cumulateRobotArm = 0;
			foreach(ArmOld arm in robots)
			{
				float unbiasedRobotPosition = arm.Position - baseSupport.Position;
				cumulateRobotArm += unbiasedRobotPosition;
			}

			float unbiasedTargetPosition = targetSupport.Position - baseSupport.Position;
			float unbiasedGravityPosition = gravity.Position - baseSupport.Position;

			return (gravity.Value * unbiasedGravityPosition - minN * unbiasedTargetPosition) / cumulateRobotArm;
		}
	}
}
