﻿namespace ForceCalculationLib.Solvers;
public struct Arm(float position)
{
	public float Position = position;
}
