﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace ForceCalculator.ViewModels
{
    public class ViewModelBase : ObservableObject
    {
    }
}
