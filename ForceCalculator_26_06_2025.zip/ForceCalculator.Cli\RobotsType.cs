namespace ForceCalculator.Cli;
public enum RobotsType
{
    AllRandom,
    Circle,
    OneLine,
    TwoLine,
    Perimeter,
}